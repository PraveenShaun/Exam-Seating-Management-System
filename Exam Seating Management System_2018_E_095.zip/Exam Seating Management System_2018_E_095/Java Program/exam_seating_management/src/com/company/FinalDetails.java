package com.company;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Vector;

public class FinalDetails extends JFrame implements ActionListener {
    private JLabel userId = new JLabel       ("Student Id               :");
    private JLabel userName = new JLabel     ("Student Name         :");
    private JLabel registeredSubject = new JLabel  ("Registered Subject :");
    private JLabel hallNumber = new JLabel   ("Hall Number            :");
    private JLabel seatNumber = new JLabel     ("Seat Number            :");

    private JLabel uID = new JLabel("");
    private JLabel uName = new JLabel("0");
   // private JLabel rSubject = new JLabel("Mathematics, Science, History, Commerce, Tamil, English");
    private JLabel hNumber = new JLabel("");
    private JLabel sNumber = new JLabel("");

    private static JTable myTable;
    Vector row = new Vector();
    Vector headers = new Vector();
    private static JScrollPane sTable = new JScrollPane(myTable);

    private static String[] subjects = {"Mathematics", "Science", "English", "History", "Tamil", "Commerce"};


    public FinalDetails(boolean[] receivedArray ,String receivedID, String receivedName, String hN, String sN) throws HeadlessException {

        this.setTitle("Exam seating Management System");
        this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        this.setResizable(false);
        this.setSize(560,280);
        this.setLayout(null);
        this.setLocationRelativeTo(null);
        this.getContentPane().setBackground(new Color(0x99C9BA));

        this.add(userId);
        userId.setBounds(30,00,200,40);
        userId.setHorizontalAlignment(JLabel.LEFT);
        userId.setVerticalAlignment(JLabel.CENTER);
        userId.setFont(new Font("Britannic Bold",Font.BOLD,18));

        this.add(uID);
        uID.setBounds(240,00,200,40);
        uID.setHorizontalAlignment(JLabel.LEFT);
        uID.setVerticalAlignment(JLabel.CENTER);
        uID.setFont(new Font("Britannic Bold",Font.BOLD,18));
        uID.setText(receivedID);

        this.add(userName);
        userName.setBounds(30,50,200,40);
        userName.setHorizontalAlignment(JLabel.LEFT);
        userName.setVerticalAlignment(JLabel.CENTER);
        userName.setFont(new Font("Britannic Bold",Font.BOLD,18));

        this.add(uName);
        uName.setBounds(240,50,200,40);
        uName.setHorizontalAlignment(JLabel.LEFT);
        uName.setVerticalAlignment(JLabel.CENTER);
        uName.setFont(new Font("Britannic Bold",Font.BOLD,18));
        uName.setText(receivedName);


        this.add(hallNumber);
        hallNumber.setBounds(30,150,200,40);
        hallNumber.setHorizontalAlignment(JLabel.LEFT);
        hallNumber.setVerticalAlignment(JLabel.CENTER);
        hallNumber.setFont(new Font("Britannic Bold",Font.BOLD,18));

        this.add(hNumber);
        hNumber.setBounds(240,150,200,40);
        hNumber.setHorizontalAlignment(JLabel.LEFT);
        hNumber.setVerticalAlignment(JLabel.CENTER);
        hNumber.setFont(new Font("Britannic Bold",Font.BOLD,18));
        hNumber.setText(hN);

        this.add(seatNumber);
        seatNumber.setBounds(30,200,200,40);
        seatNumber.setHorizontalAlignment(JLabel.LEFT);
        seatNumber.setVerticalAlignment(JLabel.CENTER);
        seatNumber.setFont(new Font("Britannic Bold",Font.BOLD,18));

        this.add(sNumber);
        sNumber.setBounds(240,200,200,40);
        sNumber.setHorizontalAlignment(JLabel.LEFT);
        sNumber.setVerticalAlignment(JLabel.CENTER);
        sNumber.setFont(new Font("Britannic Bold",Font.BOLD,18));
        sNumber.setText(sN);

        headers.addElement("Registered Subjects");
        myTable = new JTable(row, headers);
        sTable.setViewportView(myTable);
        sTable.setBounds(380,10,150,200);

        this.add(sTable);

        DefaultTableModel model = (DefaultTableModel) myTable.getModel();

        for (int i = 0; i<receivedArray.length; i++){
            if (receivedArray[i]){
                model.addRow(new Object[]{subjects[i]});
            }
        }



        this.setVisible(true);

    }


    @Override
    public void actionPerformed(ActionEvent e) {



    }
}
