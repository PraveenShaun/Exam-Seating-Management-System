package com.company;

import javax.swing.*;
import javax.swing.plaf.metal.MetalButtonUI;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class HallLayout extends JFrame implements ActionListener {
    private JPanel titlePanel = new JPanel();
    private JPanel mainPanel = new JPanel();

    private JLabel hallLabel = new JLabel("HALL:");
    private JLabel hallNum = new JLabel("");

    private JButton[] seats = new JButton[50];
    private int hallnumber = 1;

    private static Color selectedSeatColor = new Color(0xCD1478);

    private boolean[] parsingArray;
    private String parsingID;
    private String parsingName;
    //boolean[] receivedBool, String studentID
    public HallLayout(boolean[] receivedArray ,String receivedID, String receivedName){

        parsingArray = receivedArray.clone();
        parsingID = receivedID;
        parsingName = receivedName;


        this.setTitle("Hall Layout");
        this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        this.setResizable(false);
        this.setSize(new Dimension(840,570));
        //this.setVisible(true);
        this.setLayout(null);
        //this.getContentPane().setBackground(Color.GRAY);


         titlePanel.setBackground(new Color(0x606E8B));
         //titlePanel.setSize(new Dimension(700,50));
         titlePanel.setBounds(0,0,830,100);

        titlePanel.add(hallLabel);
        hallLabel.setBounds(0,0,600,60);
        hallLabel.setHorizontalAlignment(JLabel.RIGHT);
        hallLabel.setVerticalAlignment(JLabel.CENTER);
        hallLabel.setFont(new Font("Times New Roman",Font.BOLD,30));

        titlePanel.add(hallNum);
        hallNum.setBounds(600,0,100,60);
        hallNum.setHorizontalAlignment(JLabel.LEFT);
        hallNum.setVerticalAlignment(JLabel.CENTER);
        hallNum.setFont(new Font("Times New Roman",Font.BOLD,30));


         for (int i = 0; i < 50; i++){
             seats[i] = new JButton(String.valueOf(i+1));
             seats[i].setHorizontalAlignment(JLabel.CENTER);
             seats[i].setVerticalAlignment(JLabel.CENTER);
             seats[i].setOpaque(true);
             seats[i].setFocusable(false);
             seats[i].setBackground(Color.GREEN);
             seats[i].setForeground(Color.BLACK);
             seats[i].setUI(new MetalButtonUI(){
                 protected Color getDisabledTextColor(){
                     return Color.BLACK;
                 }
             });
             seats[i].setEnabled(false);
         }
        int temp=0;
         for (int i = 0; i< 10; i++){
             seats[i].setBounds(30+temp,30,50,50);
             temp=temp+80;
         }
         temp = 0;
        for (int i = 10; i< 20; i++){
            seats[i].setBounds(30+temp,110,50,50);
            temp=temp+80;
        }
        temp = 0;
        for (int i = 20; i< 30; i++){
            seats[i].setBounds(30+temp,190,50,50);
            temp=temp+80;
        }
        temp = 0;
        for (int i = 30; i< 40; i++){
            seats[i].setBounds(30+temp,270,50,50);
            temp=temp+80;
        }
        temp = 0;
        for (int i = 40; i< 50; i++){
            seats[i].setBounds(30+temp,350,50,50);
            temp=temp+80;
        }

         mainPanel.setBackground(new Color(0x94B5D7));
        // mainPanel.setSize(new Dimension(700,500));
        mainPanel.setBounds(0,100,830,430);
         //mainPanel.setLayout(new GridLayout(5,10,30,30));
        mainPanel.setLayout(null);
         for (int i=0; i <50; i++){
             mainPanel.add(seats[i]);
         }

         int lastSeatNumber = getLastSeatBooked();
         int currentSeatNumber = 0;
         currentSeatNumber = lastSeatNumber + 1;

         if (lastSeatNumber > 50){
             hallnumber = 2;
         }

         for (int j = 0 ; j < (currentSeatNumber-1); j++){
             seats[j].setBackground(new Color(0x2BB5C7));
         }

         seats[currentSeatNumber-1].setBackground(selectedSeatColor);

         hallNum.setText(String.valueOf(hallnumber));

         bookCurrentSeat(hallnumber);
         updateRegisterTable(receivedID,hallnumber,currentSeatNumber);

         new FinalDetails(parsingArray,parsingID,parsingName,String.valueOf(hallnumber),String.valueOf(currentSeatNumber));

        this.add(titlePanel);
        this.add(mainPanel);
        this.setVisible(true);

    }


    private static int getLastSeatBooked(){
        String hallNumber = "";
        String seatNumber = "";
        int number = 0;

        try {
            String url = "jdbc:mysql://localhost:3307/exam_seating_management";
            String name = "root";
            String pass = "1234";

            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(url, name, pass);
            //Statement st = con.createStatement();
            PreparedStatement query = con.prepareStatement("select * from seats order by seat_number desc limit 1;");

            ResultSet rs = query.executeQuery();
            rs.next();
            hallNumber = rs.getString("exam_hall_number");
            seatNumber = rs.getString("seat_number");

            number = Integer.parseInt(seatNumber);
            //query.executeUpdate();

            //st.close();
            query.close();
            con.close();


        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
        return number;
    }

    private static void bookCurrentSeat(int number){
        try {
            String url = "jdbc:mysql://localhost:3307/exam_seating_management";
            String name = "root";
            String pass = "1234";

            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(url, name, pass);
            //Statement st = con.createStatement();
            PreparedStatement query = con.prepareStatement("insert into seats(exam_hall_number) value(?)");
            query.setInt(1,number);

            //ResultSet rs = query.executeQuery();


            query.executeUpdate();

            //st.close();
            query.close();
            con.close();


        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }

    private static void updateRegisterTable(String stdID, int hNumb, int sNumb){
        try {
            String url = "jdbc:mysql://localhost:3307/exam_seating_management";
            String name = "root";
            String pass = "1234";

            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(url, name, pass);
            //Statement st = con.createStatement();
            PreparedStatement query = con.prepareStatement("insert into register values(?,?,?)");
            query.setString(1,stdID);
            query.setInt(2,hNumb);
            query.setInt(3,sNumb);

            //ResultSet rs = query.executeQuery();


            query.executeUpdate();

            //st.close();
            query.close();
            con.close();


        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }




    @Override
    public void actionPerformed(ActionEvent e) {


    }
}
