package com.company;

import java.io.IOException;
import java.sql.*;

public class Main {

    public static void main(String[] args) throws IOException {
        new StudentLoginGUI();
//        new StudentDetail();
//       new Subjects();
       // new HallLayout();
     //  new FinalDetails();

//        String one = "";
//        String two = "";

//        try {
//            String url = "jdbc:mysql://localhost:3307/exam_seating_management";
//            String name = "root";
//            String pass = "1234";
//
//            Class.forName("com.mysql.cj.jdbc.Driver");
//            Connection con = DriverManager.getConnection(url, name, pass);
//            //Statement st = con.createStatement();
//            PreparedStatement query = con.prepareStatement("select * from seats order by seat_number desc limit 1;");
//
//             ResultSet rs = query.executeQuery();
//             rs.next();
//             one = rs.getString("exam_hall_number");
//             two = rs.getString("seat_number");
//
//            System.out.println(one);
//            System.out.println(two);
//            //query.executeUpdate();
//
//            //st.close();
//            query.close();
//            con.close();
//
//
//        } catch (ClassNotFoundException | SQLException e) {
//            e.printStackTrace();
//        }
    }
}
