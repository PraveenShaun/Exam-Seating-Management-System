package com.company;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class StudentDetail extends JFrame implements ActionListener {
    private JLabel userId = new JLabel("Student Id         :");
    private JLabel userName = new JLabel("Student Name    :");
    private JLabel userAddress = new JLabel("Student Address :");
    private JLabel userMobile = new JLabel("Mobile Number  :");
    private JLabel userMail = new JLabel("Email Id             :");
    private static JButton register = new JButton();

    private JLabel uId = new JLabel();
    private static JLabel uName = new JLabel();
    private static JLabel uAddress = new JLabel();
    private static JLabel uMobile = new JLabel();
    private static JLabel uMail = new JLabel();

    private static String id;
    private static int isExist;


    public StudentDetail(String receivedID) throws HeadlessException {

        id = receivedID;

        this.setTitle("Exam seating Management System");
        this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        this.setResizable(false);
        this.setSize(600,400);
        this.setLayout(null);
        setLocationRelativeTo(null);

        this.add(userId);
        userId.setBounds(10,00,200,40);
        userId.setHorizontalAlignment(JLabel.LEFT);
        userId.setVerticalAlignment(JLabel.CENTER);
        userId.setFont(new Font("Times New Roman",Font.BOLD,18));

        this.add(uId);
        uId.setBounds(220,00,200,40);
        uId.setHorizontalAlignment(JLabel.LEFT);
        uId.setVerticalAlignment(JLabel.CENTER);
        uId.setFont(new Font("Times New Roman",Font.BOLD,18));
        uId.setText(receivedID);


        this.add(userName);
        userName.setBounds(10,50,200,40);
        userName.setHorizontalAlignment(JLabel.LEFT);
        userName.setVerticalAlignment(JLabel.CENTER);
        userName.setFont(new Font("Times New Roman",Font.BOLD,18));

        this.add(uName);
        uName.setBounds(220,50,300,40);
        uName.setHorizontalAlignment(JLabel.LEFT);
        uName.setVerticalAlignment(JLabel.CENTER);
        uName.setFont(new Font("Times New Roman",Font.BOLD,18));

        this.add(userAddress);
        userAddress.setBounds(10,100,200,40);
        userAddress.setHorizontalAlignment(JLabel.LEFT);
        userAddress.setVerticalAlignment(JLabel.CENTER);
        userAddress.setFont(new Font("Times New Roman",Font.BOLD,18));

        this.add(uAddress);
        uAddress.setBounds(220,100,300,40);
        uAddress.setHorizontalAlignment(JLabel.LEFT);
        uAddress.setVerticalAlignment(JLabel.CENTER);
        uAddress.setFont(new Font("Times New Roman",Font.BOLD,18));

        this.add(userMobile);
        userMobile.setBounds(10,150,200,40);
        userMobile.setHorizontalAlignment(JLabel.LEFT);
        userMobile.setVerticalAlignment(JLabel.CENTER);
        userMobile.setFont(new Font("Times New Roman",Font.BOLD,18));

        this.add(uMobile);
        uMobile.setBounds(220,150,200,40);
        uMobile.setHorizontalAlignment(JLabel.LEFT);
        uMobile.setVerticalAlignment(JLabel.CENTER);
        uMobile.setFont(new Font("Times New Roman",Font.BOLD,18));

        this.add(userMail);
        userMail.setBounds(10,200,200,40);
        userMail.setHorizontalAlignment(JLabel.LEFT);
        userMail.setVerticalAlignment(JLabel.CENTER);
        userMail.setFont(new Font("Times New Roman",Font.BOLD,18));

        this.add(uMail);
        uMail.setBounds(220,200,300,40);
        uMail.setHorizontalAlignment(JLabel.LEFT);
        uMail.setVerticalAlignment(JLabel.CENTER);
        uMail.setFont(new Font("Times New Roman",Font.BOLD,18));

        this.add(register);
        register.setText("Register For Exam");
        register.setBounds(200,250,200,40);
        register.setFocusable(false);
        register.addActionListener(this);

        updateDetails(id);

        checkAlreadyRegistered(receivedID);
        this.setVisible(true);

    }

    private static void updateDetails(String receivedId){

        try {
            String url = "jdbc:mysql://localhost:3307/exam_seating_management";
            String name = "root";
            String pass = "1234";
            //  String query = "SELECT stu_password FROM students WHERE stu_id =;

            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(url, name, pass);
            PreparedStatement query = con.prepareStatement("SELECT * FROM students WHERE stu_id =?");
            query.setString(1,receivedId);
            ResultSet rs = query.executeQuery();

            rs.next();
            uName.setText(rs.getString("stu_name"));
            uAddress.setText(rs.getString("stu_address"));
            uMobile.setText(rs.getString("stu_mobile"));
            uMail.setText(rs.getString("stu_email"));

            query.close();
            con.close();

        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }


    private static void checkAlreadyRegistered(String receivedId){

        try {
            String url = "jdbc:mysql://localhost:3307/exam_seating_management";
            String name = "root";
            String pass = "1234";
            //  String query = "SELECT stu_password FROM students WHERE stu_id =;

            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(url, name, pass);
            PreparedStatement query = con.prepareStatement("select exists (select * from registered_subjects where stu_id = ?);");
            query.setString(1,receivedId);
            ResultSet rs = query.executeQuery();

            String interpolatedString = "";
            String u1 = "exists (select * from registered_subjects where stu_id = '";
            String u2 = receivedId;
            String u3 = "')";


            //interpolatedString += String.format("u1=%s; u2%s; u3=%s;" ,u1,u2,u3);
            System.out.println(interpolatedString);
            interpolatedString = u1+u2+u3;
            rs.next();
            //isExist = rs.getInt("exists (select * from registered_subjects where stu_id = '2018/E/025')");
            isExist = rs.getInt(interpolatedString);

            System.out.println(interpolatedString);


            if (isExist == 1){
                register.setEnabled(false);
                new HallLayout2(id);

            }

            query.close();
            con.close();

        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == register){
            new Subjects(id,uName.getText());
        }



    }
}
