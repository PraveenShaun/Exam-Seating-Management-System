package com.company;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.sql.*;

public class StudentLoginGUI extends JFrame implements ActionListener {
    private JLabel title = new JLabel("Exam Seating Management");
    private JLabel titleLabel = new JLabel("Student Login");
    private JLabel userName = new JLabel("Student ID:");
    private static JTextField uname = new JTextField("");
    private JLabel password = new JLabel("Password:");
    private static JPasswordField pass = new JPasswordField("");
    private JButton login = new JButton();

    private static String enteredUserName;
    private static String enteredPassword;
    private static boolean isEmpty = true;


    StudentLoginGUI() throws IOException {

        this.setTitle("Exam seating Management System");
        this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        this.setResizable(false);
        this.setSize(700,440);
        this.setLayout(null);
        this.setLocationRelativeTo(null);


        JLabel picLabel = new JLabel();
        picLabel.setBounds(300,80,113,113);
        picLabel.setOpaque(true);
        picLabel.setIcon(new ImageIcon("D:\\login.jpg"));
        this.add(picLabel);

        this.add(title);
        title.setBounds(0,20,700,30);
        title.setHorizontalAlignment(JLabel.CENTER);
        title.setVerticalAlignment(JLabel.CENTER);
        title.setFont(new Font("Britannic Bold",Font.BOLD,30));
        title.setForeground(Color.BLUE);

        this.add(titleLabel);
        titleLabel.setBounds(0,50,700,30);
        titleLabel.setHorizontalAlignment(JLabel.CENTER);
        titleLabel.setVerticalAlignment(JLabel.CENTER);
        titleLabel.setFont(new Font("Times New Roman",Font.BOLD,25));


        this.add(userName);
        userName.setBounds(20,200,250,40);
        userName.setHorizontalAlignment(JLabel.LEFT);
        userName.setVerticalAlignment(JLabel.CENTER);
        userName.setFont(new Font("Times New Roman",Font.BOLD,25));

        this.add(uname);
        uname.setBounds(250,200,200,35);


        this.add(password);
        password.setBounds(20,260,150,40);
        password.setHorizontalAlignment(JLabel.LEFT);
        password.setVerticalAlignment(JLabel.CENTER);
        password.setFont(new Font("Times New Roman",Font.BOLD,25));

        this.add(pass);
        pass.setBounds(250,260,200,35);


        this.add(login);
        login.setText("Login");
        login.setBounds(250,340,200,40);
        login.setFocusable(false);
        login.addActionListener(this);


//        try {
//            String url = "jdbc:mysql://localhost:3307/exam_seating_management";
//            String name = "root";
//            String pass = "1234";
//            String query = "SELECT * FROM students WHERE stu_id = '2018/E/070'";
//
//            Class.forName("com.mysql.cj.jdbc.Driver");
//            Connection con = DriverManager.getConnection(url, name, pass);
//            Statement st = con.createStatement();
//            ResultSet rs = st.executeQuery(query);
//
//            rs.next();
//            String output = rs.getString("stu_name");
//            st.close();
//            con.close();
//
//            System.out.println(output);
//
//
//        } catch (ClassNotFoundException | SQLException e) {
//            e.printStackTrace();
//        }

        this.setVisible(true);

    }

    private static void isTextBoxEmpty(){
        String[] textBoxes = new String[2];

        textBoxes[0] = uname.getText().toString();
        textBoxes[1] = pass.getText().toString();
        int j =0;
        for (int i=0; i<2;i++){
            if (textBoxes[i].isEmpty()){
                j++;
            }
        }

        if (j == 0){
            isEmpty = false;
        }

        if (j > 0){
            isEmpty =true;
        }
    }

    private static String getPasswordFromDatabase(String id){
        String output = "";
        try {
            String url = "jdbc:mysql://localhost:3307/exam_seating_management";
            String name = "root";
            String pass = "1234";
          //  String query = "SELECT stu_password FROM students WHERE stu_id =;

            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(url, name, pass);
            //Statement st = con.createStatement();
            PreparedStatement query = con.prepareStatement("SELECT stu_password FROM students WHERE stu_id =?");
            query.setString(1,id);
            ResultSet rs = query.executeQuery();

            rs.next();
            output = rs.getString("stu_password");
            //st.close();
            query.close();
            con.close();

            System.out.println(output);


        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
        return output;
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == login){
            isTextBoxEmpty();
            System.out.println(uname.getText());
            System.out.println(pass.getText());
            System.out.println(isEmpty);
            if (isEmpty){
                JOptionPane.showMessageDialog(this,"Student ID or password cannot be empty");
            }
            else {
                enteredUserName = uname.getText();
                enteredPassword = String.valueOf(pass.getPassword());

                String passwordFromDatabase = getPasswordFromDatabase(enteredUserName);

                if (passwordFromDatabase.equals(enteredPassword)){
                    JOptionPane.showMessageDialog(this,"Login successful");
                    new StudentDetail(enteredUserName);
                    this.dispose();
                }
                else {
                    JOptionPane.showMessageDialog(this,"Incorrect user name or password");
                }

            }


        }

    }
}
