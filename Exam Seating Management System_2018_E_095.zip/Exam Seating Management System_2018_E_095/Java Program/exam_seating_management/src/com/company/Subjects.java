package com.company;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.util.ArrayList;

public class Subjects extends JFrame implements ActionListener {
    private JLabel maths = new JLabel("Mathematics ");
    private JLabel science = new JLabel("Science     ");
    private JLabel english = new JLabel("English     ");
    private JLabel history = new JLabel("History     ");
    private JLabel tamil = new JLabel("Tamil       ");
    private JLabel commerce = new JLabel("Commerce    ");


    // Buttons
    private JButton mathsButton = new JButton();
    private JButton scienceButton = new JButton();
    private JButton englishButton = new JButton();
    private JButton historyButton = new JButton();
    private JButton tamilButton = new JButton();
    private JButton commerceButton = new JButton();
    private JButton finalRegister = new JButton();

    private static ArrayList<String> selectedSubjects = new ArrayList<>();


    private static boolean[] selectedBool = new boolean[6];
    private static int[] selected = new int[6];

    private static String id = "";
    private static String  parsingID;
    private String parsingName;

    public Subjects(String receivedID,  String receivedName) throws HeadlessException {
        id = receivedID;
        parsingID = receivedID;
        parsingName = receivedName;


        this.setTitle("Subject Registration");
        this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        this.setResizable(false);
        this.setSize(600,500);
        this.setVisible(true);
        this.setLayout(null);
        this.setLocationRelativeTo(null);

        this.add(maths);
        maths.setBounds(10,00,200,40);
        maths.setHorizontalAlignment(JLabel.LEFT);
        maths.setVerticalAlignment(JLabel.CENTER);
        maths.setFont(new Font("Times New Roman",Font.BOLD,18));


        this.add(science);
        science.setBounds(10,50,200,40);
        science.setHorizontalAlignment(JLabel.LEFT);
        science.setVerticalAlignment(JLabel.CENTER);
        science.setFont(new Font("Times New Roman",Font.BOLD,18));

        this.add(english);
        english.setBounds(10,100,200,40);
        english.setHorizontalAlignment(JLabel.LEFT);
        english.setVerticalAlignment(JLabel.CENTER);
        english.setFont(new Font("Times New Roman",Font.BOLD,18));

        this.add(history);
        history.setBounds(10,150,200,40);
        history.setHorizontalAlignment(JLabel.LEFT);
        history.setVerticalAlignment(JLabel.CENTER);
        history.setFont(new Font("Times New Roman",Font.BOLD,18));

        this.add(tamil);
        tamil.setBounds(10,200,200,40);
        tamil.setHorizontalAlignment(JLabel.LEFT);
        tamil.setVerticalAlignment(JLabel.CENTER);
        tamil.setFont(new Font("Times New Roman",Font.BOLD,18));

        this.add(commerce);
        commerce.setBounds(10,250,200,40);
        commerce.setHorizontalAlignment(JLabel.LEFT);
        commerce.setVerticalAlignment(JLabel.CENTER);
        commerce.setFont(new Font("Times New Roman",Font.BOLD,18));


        //Button
        this.add(mathsButton);
        mathsButton.setText("Register For Exam");
        mathsButton.setBounds(200,00,200,40);
        mathsButton.setFocusable(false);
        mathsButton.addActionListener(this);

        this.add(scienceButton);
        scienceButton.setText("Register For Exam");
        scienceButton.setBounds(200,50,200,40);
        scienceButton.setFocusable(false);
        scienceButton.addActionListener(this);

        this.add(englishButton);
        englishButton.setText("Register For Exam");
        englishButton.setBounds(200,100,200,40);
        englishButton.setFocusable(false);
        englishButton.addActionListener(this);

        this.add(historyButton);
        historyButton.setText("Register For Exam");
        historyButton.setBounds(200,150,200,40);
        historyButton.setFocusable(false);
        historyButton.addActionListener(this);

        this.add(tamilButton);
        tamilButton.setText("Register For Exam");
        tamilButton.setBounds(200,200,200,40);
        tamilButton.setFocusable(false);
        tamilButton.addActionListener(this);

        this.add(commerceButton);
        commerceButton.setText("Register For Exam");
        commerceButton.setBounds(200,250,200,40);
        commerceButton.setFocusable(false);
        commerceButton.addActionListener(this);

        this.add(finalRegister);
        finalRegister.setText("Submit");
        finalRegister.setBounds(200,350,200,40);
        finalRegister.setFocusable(false);
        finalRegister.addActionListener(this);
        finalRegister.setEnabled(false);



        this.setVisible(true);
    }

    private static void updateRegisteredSubjectFromDatabase(){

        try {
            String url = "jdbc:mysql://localhost:3307/exam_seating_management";
            String name = "root";
            String pass = "1234";

            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(url, name, pass);
            //Statement st = con.createStatement();
            PreparedStatement query = con.prepareStatement("INSERT INTO registered_subjects VALUES (?,?,?,?,?,?,?)");
            query.setString(1,id);
            query.setInt(2,selected[0]);
            query.setInt(3,selected[1]);
            query.setInt(4,selected[2]);
            query.setInt(5,selected[3]);
            query.setInt(6,selected[4]);
            query.setInt(7,selected[5]);
           // ResultSet rs = query.executeQuery();
            query.executeUpdate();

            //st.close();
            query.close();
            con.close();


        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == mathsButton){
            mathsButton.setEnabled(false);
            selectedSubjects.add("Mathematics");
            selectedBool[0] = true;
            selected[0] = 1;
            finalRegister.setEnabled(true);
            super.update(this.getGraphics());
        }

        if (e.getSource() == scienceButton){
            scienceButton.setEnabled(false);
            selectedSubjects.add("Science");
            selectedBool[1] = true;
            selected[1] = 1;
            finalRegister.setEnabled(true);
            super.update(this.getGraphics());
        }

        if (e.getSource() == englishButton){
            englishButton.setEnabled(false);
            selectedSubjects.add("English");
            selectedBool[2] = true;
            selected[2] = 1;
            finalRegister.setEnabled(true);
            super.update(this.getGraphics());
        }

        if (e.getSource() == historyButton){
            historyButton.setEnabled(false);
            selectedSubjects.add("History");
            selectedBool[3] = true;
            selected[3] = 1;
            finalRegister.setEnabled(true);
            super.update(this.getGraphics());
        }

        if (e.getSource() == tamilButton){
            tamilButton.setEnabled(false);
            selectedSubjects.add("Tamil");
            selectedBool[4] = true;
            selected[4] = 1;
            finalRegister.setEnabled(true);
            super.update(this.getGraphics());
        }

        if (e.getSource() == commerceButton){
            commerceButton.setEnabled(false);
            selectedSubjects.add("Commerce");
            selectedBool[5] = true;
            selected[5] = 1;
            finalRegister.setEnabled(true);
            super.update(this.getGraphics());
        }


        if (e.getSource() == finalRegister){
            updateRegisteredSubjectFromDatabase();

            new HallLayout(selectedBool,parsingID,parsingName);
           // new FinalDetails(selectedBool);
            this.dispose();

        }



    }
}
