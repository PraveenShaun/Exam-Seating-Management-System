-- MySQL dump 10.13  Distrib 8.0.27, for Win64 (x86_64)
--
-- Host: localhost    Database: exam_seating_management
-- ------------------------------------------------------
-- Server version	8.0.27

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `students`
--

DROP TABLE IF EXISTS `students`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `students` (
  `stu_id` varchar(15) NOT NULL,
  `stu_name` varchar(30) NOT NULL,
  `stu_address` varchar(100) NOT NULL,
  `stu_mobile` int DEFAULT NULL,
  `stu_email` varchar(50) NOT NULL,
  `stu_password` varchar(30) NOT NULL,
  PRIMARY KEY (`stu_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `students`
--

LOCK TABLES `students` WRITE;
/*!40000 ALTER TABLE `students` DISABLE KEYS */;
INSERT INTO `students` VALUES ('2018/E/001','Naif','No 03, kks road, Jaffna.',777598312,'Naif@gmail.com','pass'),('2018/E/004','kajamohan','No 06, Main Road, Kattankudy 06.',777598384,'kajamohan@gmail.com','pass'),('2018/E/005','Aslam','No 07, Central Road, Kattankudy 06.',777598384,'Aslam@gmail.com','pass'),('2018/E/006','Gobeesan','No 08, Shanmuga road, Trincomalee.',761927100,'Gobeesan@gmail.com','pass'),('2018/E/007','Gobishangar','No 09, Central Road, Kattankudy 06.',777598384,'Gobishangar@gmail.com','pass'),('2018/E/008','Anuvathan','No 10,Central Road, Kattankudy 06.',777598384,'Anuvathan@gmail.com','pass'),('2018/E/009','Ibrahim','No 11,Main Road, Kattankudy 06.',777598384,'Ibrahim@gmail.com','pass'),('2018/E/010','Nubly','No 12, Shanmuga road, Trincomalee.',761927100,'Nubly@gmail.com','pass'),('2018/E/011','Ragul','No 13, Central Road, Kattankudy 06.',777598384,'Ragul@gmail.com','pass'),('2018/E/012','Arshath','No 03, Jinnah Lane, Kattankudy 06.',777598384,'arshathjm@gmail.com','pass'),('2018/E/013','Miyusan','No 15, Central Road, Kattankudy 06.',777598384,'Miyusan@gmail.com','pass'),('2018/E/014','Shenal','No 16, Shanmuga road, Trincomalee.',761927100,'Shenal@gmail.com','pass'),('2018/E/015','Channa','No 17, Central Road, Kattankudy 06.',777598384,'Channa@gmail.com','pass'),('2018/E/016','Sameer','No 18, Main Road, Kattankudy 06.',777598384,'Sameer@gmail.com','pass'),('2018/E/017','Nazir','No 19,Central Road, Kattankudy 06.',777598384,'Nazir@gmail.com','pass'),('2018/E/018','Paheetharan','No 20, Shanmuga road, Trincomalee.',761927100,'Paheetharan@gmail.com','pass'),('2018/E/019','Jeyaprakash','No 21 ,Central Road, Kattankudy 06.',777598384,'Jeyaprakash@gmail.com','pass'),('2018/E/020','Thiru','No 22, Main Road, Kattankudy 06.',777598384,'Thiru@gmail.com','pass'),('2018/E/021','Lahiru','No 23, Central Road, Kattankudy 06.',777598384,'Lahiru@gmail.com','pass'),('2018/E/022','Danuksan','No 24, Shanmuga road, Trincomalee.',761927100,'Danuksan@gmail.com','pass'),('2018/E/023','Kuhan','No 25,Central Road, Kattankudy 06.',777598384,'Kuhan@gmail.com','pass'),('2018/E/024','Sulaksana','No 26, Main Roade, Kattankudy 06.',777598384,'Sulaksana@gmail.com','pass'),('2018/E/025','Tharani','No 27, Central Road, Kattankudy 06.',777598384,'Tharani@gmail.com','pass'),('2018/E/026','Tom','No 28, Shanmuga road, Trincomalee.',761927100,'Tom@gmail.com','pass'),('2018/E/027','Azam','No 29, Main Road, Kattankudy 06.',777598384,'Azam@gmail.com','pass'),('2018/E/028','Suganyan','No 30, Central Road, Kattankudy 06.',777598384,'Suganyan@gmail.com','pass'),('2018/E/029','Sathurjan','No 31, Central Road, Kattankudy 06.',777598384,'Sathurjan@gmail.com','pass'),('2018/E/030','Vineescar','No 32, Shanmuga road, Trincomalee.',761927100,'Vineescar@gmail.com','pass'),('2018/E/031','Ranjan','No 33,Central Road, Kattankudy 06.',777598384,'Ranjan@gmail.com','pass'),('2018/E/032','Raj','No 34, Central Road, Kattankudy 06.',777598384,'Raj@gmail.com','pass'),('2018/E/033','Prasanna','No 35, Central Road, Kattankudy 06.',777598384,'Prasanna@gmail.com','pass'),('2018/E/034','Vithursan','No 36, Shanmuga road, Trincomalee.',761927100,'Vithursan@gmail.com','pass'),('2018/E/035','Sajeef','No 38, Main Road, Kattankudy 06.',777598384,'Sajeef@gmail.com','pass'),('2018/E/036','Roshni','No 39,Central Road, Kattankudy 06.',777598384,'Roshni@gmail.com','pass'),('2018/E/037','Kajeevan','No 40, Shanmuga road, Trincomalee.',761927100,'Kajeevan@gmail.com','pass'),('2018/E/038','Kishanth','No 41, Main Road, Kattankudy 06.',777598384,'Kishanth@gmail.com','pass'),('2018/E/039','Thasanth','No 42,Central Road, Kattankudy 06.',777598384,'Thasanth@gmail.com','pass'),('2018/E/040','James','No 42, Main Road, Kattankudy 06.',777598384,'James@gmail.com','pass'),('2018/E/041','Puviraj','No 43, Shanmuga road, Trincomalee.',761927100,'Puviraj@gmail.com','pass'),('2018/E/042','Kobiraj','No 44,Central Road, Kattankudy 06.',777598384,'Kobiraj@gmail.com','pass'),('2018/E/043','Vinoth','No 45, Main Road, Kattankudy 06.',777598384,'Vinoth@gmail.com','pass'),('2018/E/044','Kishore','No 46,Central Road, Kattankudy 06.',777598384,'Kishore@gmail.com','pass'),('2018/E/045','Anne','No 47, Shanmuga road, Trincomalee.',761927100,'Anne@gmail.com','pass'),('2018/E/046','Dilshan','No 48, Main Road, Kattankudy 06.',777598384,'Dilshan@gmail.com','pass'),('2018/E/047','Perera','No 49,Central Road, Kattankudy 06.',777598384,'Perera@gmail.com','pass'),('2018/E/048','Saranraj','No 50,Central Road, Kattankudy 06.',777598384,'Saranraj@gmail.com','pass'),('2018/E/049','Sathursan','No 51, Shanmuga road, Trincomalee.',761927100,'Sathursan@gmail.com','pass'),('2018/E/050','Pavithran','No 52, Main Road, Kattankudy 06.',777598384,'Pavithran@gmail.com','pass'),('2018/E/051','Arunraj','No 53, Central Road, Kattankudy 06.',777598384,'Arunraj@gmail.com','pass'),('2018/E/052','Ajith','No 54, Main Road, Kattankudy 06.',777598384,'Ajith@gmail.com','pass'),('2018/E/053','Arjun','No 55, Shanmuga road, Trincomalee.',761927100,'Arjun@gmail.com','pass'),('2018/E/054','Anuruththan','No 56,Central Road, Kattankudy 06.',777598384,'Anuruththan@gmail.com','pass'),('2018/E/055','Sukizan','No 57, Central Road, Kattankudy 06.',777598384,'Sukizan@gmail.com','pass'),('2018/E/056','Niloj','No 58,Main Road, Kattankudy 06.',777598384,'Niloj@gmail.com','pass'),('2018/E/057','Vivursan','No 59, Shanmuga road, Trincomalee.',761927100,'Vivursan@gmail.com','pass'),('2018/E/058','Sisila','No 60,Central Road, Kattankudy 06.',777598384,'Sisila@gmail.com','pass'),('2018/E/059','Dhamsara','No 61,Central Road, Kattankudy 06.',777598384,'Dhamsara@gmail.com','pass'),('2018/E/060','Dinesh','No 62, Main Road, Kattankudy 06.',777598384,'Dinesh@gmail.com','pass'),('2018/E/070','Laksman','No 75, Shanmuga road, Trincomalee.',761927100,'pklaksman@gmail.com','pk123');
/*!40000 ALTER TABLE `students` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-01-26 22:14:28
