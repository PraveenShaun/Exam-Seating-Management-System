USE exam_seating_management;
CREATE TABLE students(
	stu_id VARCHAR(15) NOT NULL,
    stu_name VARCHAR(30) NOT NULL,
    stu_address VARCHAR(100) NOT NULL,
    stu_mobile INT(12) ,
    stu_emailsubjects VARCHAR(50) NOT NULL,
    stu_password VARCHAR(30) NOT NULL,
    PRIMARY KEY (stu_id)
);

SELECT * FROM students;
SELECT stu_password FROM students WHERE stu_id ='2018/E/012';
describe seats;
select stu_id from registered_subjects where exists (select stu_id from registered_subjects where stu_id = '2018/E/012');

INSERT INTO students(stu_id, stu_name, stu_address, stu_mobile, stu_email, stu_password) VALUES ('2018/E/001','Naif','No 03, kks road, Jaffna.', 0777598312, 'Naif@gmail.com', 'pass');
INSERT INTO students(stu_id, stu_name, stu_address, stu_mobile, stu_email, stu_password) VALUES ('2018/E/004','kajamohan','No 06, Main Road, Kattankudy 06.', 0777598384, 'kajamohan@gmail.com', 'pass');
INSERT INTO students(stu_id, stu_name, stu_address, stu_mobile, stu_email, stu_password) VALUES ('2018/E/005','Aslam','No 07, Central Road, Kattankudy 06.', 0777598384, 'Aslam@gmail.com', 'pass');
INSERT INTO students(stu_id, stu_name, stu_address, stu_mobile, stu_email, stu_password) VALUES ('2018/E/006','Gobeesan','No 08, Shanmuga road, Trincomalee.', 0761927100, 'Gobeesan@gmail.com', 'pass');
INSERT INTO students(stu_id, stu_name, stu_address, stu_mobile, stu_email, stu_password) VALUES ('2018/E/007','Gobishangar','No 09, Central Road, Kattankudy 06.', 0777598384, 'Gobishangar@gmail.com', 'pass');
INSERT INTO students(stu_id, stu_name, stu_address, stu_mobile, stu_email, stu_password) VALUES ('2018/E/008','Anuvathan','No 10,Central Road, Kattankudy 06.', 0777598384, 'Anuvathan@gmail.com', 'pass');
INSERT INTO students(stu_id, stu_name, stu_address, stu_mobile, stu_email, stu_password) VALUES ('2018/E/009','Ibrahim','No 11,Main Road, Kattankudy 06.', 0777598384, 'Ibrahim@gmail.com', 'pass');
INSERT INTO students(stu_id, stu_name, stu_address, stu_mobile, stu_email, stu_password) VALUES ('2018/E/010','Nubly','No 12, Shanmuga road, Trincomalee.', 0761927100, 'Nubly@gmail.com', 'pass');
INSERT INTO students(stu_id, stu_name, stu_address, stu_mobile, stu_email, stu_password) VALUES ('2018/E/011','Ragul','No 13, Central Road, Kattankudy 06.', 0777598384, 'Ragul@gmail.com', 'pass');
INSERT INTO students(stu_id, stu_name, stu_address, stu_mobile, stu_email, stu_password) VALUES ('2018/E/012','Supun','No 14, Main Road, Kattankudy 06.', 0777598384, 'Supun@gmail.com', 'pass');
INSERT INTO students(stu_id, stu_name, stu_address, stu_mobile, stu_email, stu_password) VALUES ('2018/E/013','Miyusan','No 15, Central Road, Kattankudy 06.', 0777598384, 'Miyusan@gmail.com', 'pass');
INSERT INTO students(stu_id, stu_name, stu_address, stu_mobile, stu_email, stu_password) VALUES ('2018/E/014','Shenal','No 16, Shanmuga road, Trincomalee.', 0761927100, 'Shenal@gmail.com', 'pass');
INSERT INTO students(stu_id, stu_name, stu_address, stu_mobile, stu_email, stu_password) VALUES ('2018/E/015','Channa','No 17, Central Road, Kattankudy 06.', 0777598384, 'Channa@gmail.com', 'pass');
INSERT INTO students(stu_id, stu_name, stu_address, stu_mobile, stu_email, stu_password) VALUES ('2018/E/016','Sameer','No 18, Main Road, Kattankudy 06.', 0777598384, 'Sameer@gmail.com', 'pass');
INSERT INTO students(stu_id, stu_name, stu_address, stu_mobile, stu_email, stu_password) VALUES ('2018/E/017','Nazir','No 19,Central Road, Kattankudy 06.', 0777598384, 'Nazir@gmail.com', 'pass');
INSERT INTO students(stu_id, stu_name, stu_address, stu_mobile, stu_email, stu_password) VALUES ('2018/E/018','Paheetharan','No 20, Shanmuga road, Trincomalee.', 0761927100, 'Paheetharan@gmail.com', 'pass');
INSERT INTO students(stu_id, stu_name, stu_address, stu_mobile, stu_email, stu_password) VALUES ('2018/E/019','Jeyaprakash','No 21 ,Central Road, Kattankudy 06.', 0777598384, 'Jeyaprakash@gmail.com', 'pass');
INSERT INTO students(stu_id, stu_name, stu_address, stu_mobile, stu_email, stu_password) VALUES ('2018/E/020','Thiru','No 22, Main Road, Kattankudy 06.', 0777598384, 'Thiru@gmail.com', 'pass');
INSERT INTO students(stu_id, stu_name, stu_address, stu_mobile, stu_email, stu_password) VALUES ('2018/E/021','Lahiru','No 23, Central Road, Kattankudy 06.', 0777598384, 'Lahiru@gmail.com', 'pass');
INSERT INTO students(stu_id, stu_name, stu_address, stu_mobile, stu_email, stu_password) VALUES ('2018/E/022','Danuksan','No 24, Shanmuga road, Trincomalee.', 0761927100, 'Danuksan@gmail.com', 'pass');
INSERT INTO students(stu_id, stu_name, stu_address, stu_mobile, stu_email, stu_password) VALUES ('2018/E/023','Kuhan','No 25,Central Road, Kattankudy 06.', 0777598384, 'Kuhan@gmail.com', 'pass');
INSERT INTO students(stu_id, stu_name, stu_address, stu_mobile, stu_email, stu_password) VALUES ('2018/E/024','Sulaksana','No 26, Main Roade, Kattankudy 06.', 0777598384, 'Sulaksana@gmail.com', 'pass');
INSERT INTO students(stu_id, stu_name, stu_address, stu_mobile, stu_email, stu_password) VALUES ('2018/E/025','Tharani','No 27, Central Road, Kattankudy 06.', 0777598384, 'Tharani@gmail.com', 'pass');
INSERT INTO students(stu_id, stu_name, stu_address, stu_mobile, stu_email, stu_password) VALUES ('2018/E/026','Tom','No 28, Shanmuga road, Trincomalee.', 0761927100, 'Tom@gmail.com', 'pass');
INSERT INTO students(stu_id, stu_name, stu_address, stu_mobile, stu_email, stu_password) VALUES ('2018/E/027','Azam','No 29, Main Road, Kattankudy 06.', 0777598384, 'Azam@gmail.com', 'pass');
INSERT INTO students(stu_id, stu_name, stu_address, stu_mobile, stu_email, stu_password) VALUES ('2018/E/028','Suganyan','No 30, Central Road, Kattankudy 06.', 0777598384, 'Suganyan@gmail.com', 'pass');
INSERT INTO students(stu_id, stu_name, stu_address, stu_mobile, stu_email, stu_password) VALUES ('2018/E/029','Sathurjan','No 31, Central Road, Kattankudy 06.', 0777598384, 'Sathurjan@gmail.com', 'pass');
INSERT INTO students(stu_id, stu_name, stu_address, stu_mobile, stu_email, stu_password) VALUES ('2018/E/030','Vineescar','No 32, Shanmuga road, Trincomalee.', 0761927100, 'Vineescar@gmail.com', 'pass');
INSERT INTO students(stu_id, stu_name, stu_address, stu_mobile, stu_email, stu_password) VALUES ('2018/E/031','Ranjan','No 33,Central Road, Kattankudy 06.', 0777598384, 'Ranjan@gmail.com', 'pass');
INSERT INTO students(stu_id, stu_name, stu_address, stu_mobile, stu_email, stu_password) VALUES ('2018/E/032','Raj','No 34, Central Road, Kattankudy 06.', 0777598384, 'Raj@gmail.com', 'pass');
INSERT INTO students(stu_id, stu_name, stu_address, stu_mobile, stu_email, stu_password) VALUES ('2018/E/033','Prasanna','No 35, Central Road, Kattankudy 06.', 0777598384, 'Prasanna@gmail.com', 'pass');
INSERT INTO students(stu_id, stu_name, stu_address, stu_mobile, stu_email, stu_password) VALUES ('2018/E/034','Vithursan','No 36, Shanmuga road, Trincomalee.', 0761927100, 'Vithursan@gmail.com', 'pass');
INSERT INTO students(stu_id, stu_name, stu_address, stu_mobile, stu_email, stu_password) VALUES ('2018/E/034','Kavinas','No 37, Central Road, Kattankudy 06.', 0777598384, 'Kavinas@gmail.com', 'pass');
INSERT INTO students(stu_id, stu_name, stu_address, stu_mobile, stu_email, stu_password) VALUES ('2018/E/035','Sajeef','No 38, Main Road, Kattankudy 06.', 0777598384, 'Sajeef@gmail.com', 'pass');
INSERT INTO students(stu_id, stu_name, stu_address, stu_mobile, stu_email, stu_password) VALUES ('2018/E/036','Roshni','No 39,Central Road, Kattankudy 06.', 0777598384, 'Roshni@gmail.com', 'pass');
INSERT INTO students(stu_id, stu_name, stu_address, stu_mobile, stu_email, stu_password) VALUES ('2018/E/037','Kajeevan','No 40, Shanmuga road, Trincomalee.', 0761927100, 'Kajeevan@gmail.com', 'pass');
INSERT INTO students(stu_id, stu_name, stu_address, stu_mobile, stu_email, stu_password) VALUES ('2018/E/038','Kishanth','No 41, Main Road, Kattankudy 06.', 0777598384, 'Kishanth@gmail.com', 'pass');
INSERT INTO students(stu_id, stu_name, stu_address, stu_mobile, stu_email, stu_password) VALUES ('2018/E/039','Thasanth','No 42,Central Road, Kattankudy 06.', 0777598384, 'Thasanth@gmail.com', 'pass');
INSERT INTO students(stu_id, stu_name, stu_address, stu_mobile, stu_email, stu_password) VALUES ('2018/E/040','James','No 42, Main Road, Kattankudy 06.', 0777598384, 'James@gmail.com', 'pass');
INSERT INTO students(stu_id, stu_name, stu_address, stu_mobile, stu_email, stu_password) VALUES ('2018/E/041','Puviraj','No 43, Shanmuga road, Trincomalee.', 0761927100, 'Puviraj@gmail.com', 'pass');
INSERT INTO students(stu_id, stu_name, stu_address, stu_mobile, stu_email, stu_password) VALUES ('2018/E/042','Kobiraj','No 44,Central Road, Kattankudy 06.', 0777598384, 'Kobiraj@gmail.com', 'pass');
INSERT INTO students(stu_id, stu_name, stu_address, stu_mobile, stu_email, stu_password) VALUES ('2018/E/043','Vinoth','No 45, Main Road, Kattankudy 06.', 0777598384, 'Vinoth@gmail.com', 'pass');
INSERT INTO students(stu_id, stu_name, stu_address, stu_mobile, stu_email, stu_password) VALUES ('2018/E/044','Kishore','No 46,Central Road, Kattankudy 06.', 0777598384, 'Kishore@gmail.com', 'pass');
INSERT INTO students(stu_id, stu_name, stu_address, stu_mobile, stu_email, stu_password) VALUES ('2018/E/045','Anne','No 47, Shanmuga road, Trincomalee.', 0761927100, 'Anne@gmail.com', 'pass');
INSERT INTO students(stu_id, stu_name, stu_address, stu_mobile, stu_email, stu_password) VALUES ('2018/E/046','Dilshan','No 48, Main Road, Kattankudy 06.', 0777598384, 'Dilshan@gmail.com', 'pass');
INSERT INTO students(stu_id, stu_name, stu_address, stu_mobile, stu_email, stu_password) VALUES ('2018/E/047','Perera','No 49,Central Road, Kattankudy 06.', 0777598384, 'Perera@gmail.com', 'pass');
INSERT INTO students(stu_id, stu_name, stu_address, stu_mobile, stu_email, stu_password) VALUES ('2018/E/048','Saranraj','No 50,Central Road, Kattankudy 06.', 0777598384, 'Saranraj@gmail.com', 'pass');
INSERT INTO students(stu_id, stu_name, stu_address, stu_mobile, stu_email, stu_password) VALUES ('2018/E/049','Sathursan','No 51, Shanmuga road, Trincomalee.', 0761927100, 'Sathursan@gmail.com', 'pass');
INSERT INTO students(stu_id, stu_name, stu_address, stu_mobile, stu_email, stu_password) VALUES ('2018/E/050','Pavithran','No 52, Main Road, Kattankudy 06.', 0777598384, 'Pavithran@gmail.com', 'pass');
INSERT INTO students(stu_id, stu_name, stu_address, stu_mobile, stu_email, stu_password) VALUES ('2018/E/051','Arunraj','No 53, Central Road, Kattankudy 06.', 0777598384, 'Arunraj@gmail.com', 'pass');
INSERT INTO students(stu_id, stu_name, stu_address, stu_mobile, stu_email, stu_password) VALUES ('2018/E/052','Ajith','No 54, Main Road, Kattankudy 06.', 0777598384, 'Ajith@gmail.com', 'pass');
INSERT INTO students(stu_id, stu_name, stu_address, stu_mobile, stu_email, stu_password) VALUES ('2018/E/053','Arjun','No 55, Shanmuga road, Trincomalee.', 0761927100, 'Arjun@gmail.com', 'pass');
INSERT INTO students(stu_id, stu_name, stu_address, stu_mobile, stu_email, stu_password) VALUES ('2018/E/054','Anuruththan','No 56,Central Road, Kattankudy 06.', 0777598384, 'Anuruththan@gmail.com', 'pass');
INSERT INTO students(stu_id, stu_name, stu_address, stu_mobile, stu_email, stu_password) VALUES ('2018/E/055','Sukizan','No 57, Central Road, Kattankudy 06.', 0777598384, 'Sukizan@gmail.com', 'pass');
INSERT INTO students(stu_id, stu_name, stu_address, stu_mobile, stu_email, stu_password) VALUES ('2018/E/056','Niloj','No 58,Main Road, Kattankudy 06.', 0777598384, 'Niloj@gmail.com', 'pass');
INSERT INTO students(stu_id, stu_name, stu_address, stu_mobile, stu_email, stu_password) VALUES ('2018/E/057','Vivursan','No 59, Shanmuga road, Trincomalee.', 0761927100, 'Vivursan@gmail.com', 'pass');
INSERT INTO students(stu_id, stu_name, stu_address, stu_mobile, stu_email, stu_password) VALUES ('2018/E/058','Sisila','No 60,Central Road, Kattankudy 06.', 0777598384, 'Sisila@gmail.com', 'pass');
INSERT INTO students(stu_id, stu_name, stu_address, stu_mobile, stu_email, stu_password) VALUES ('2018/E/059','Dhamsara','No 61,Central Road, Kattankudy 06.', 0777598384, 'Dhamsara@gmail.com', 'pass');
INSERT INTO students(stu_id, stu_name, stu_address, stu_mobile, stu_email, stu_password) VALUES ('2018/E/060','Dinesh','No 62, Main Road, Kattankudy 06.', 0777598384, 'Dinesh@gmail.com', 'pass');

 CREATE TABLE subjects(
 subject_name VARCHAR(15) NOT NULL,
 subject_id VARCHAR(15) NOT NULL,
 PRIMARY KEY (subject_id)
);

CREATE TABLE exam_halls(
	exam_hall_number INT NOT NULL,
    hall_description VARCHAR(50),
    PRIMARY KEY(exam_hall_number)
);

CREATE TABLE register(
	stu_id VARCHAR(15) NOT NULL,
    exam_id VARCHAR(15) NOT NULL
);

CREATE TABLE registered_subjects(
	stu_id VARCHAR(15) NOT NULL,
    maths BOOLEAN NOT NULL,
    science BOOLEAN NOT NULL,
    english BOOLEAN NOT NULL,
    hist BOOLEAN NOT NULL,
    tamil BOOLEAN NOT NULL,
    commerce BOOLEAN NOT NULL
    );
    
    ALTER TABLE registered_subjects ADD PRIMARY KEY(stu_id);

ALTER TABLE register
ADD FOREIGN KEY (stu_id)
REFERENCES students(stu_id);

CREATE TABLE seats(
    exam_hall_number INT NOT NULL,
    seat_number INT NOT NULL,
    PRIMARY KEY(seat_number)
);
